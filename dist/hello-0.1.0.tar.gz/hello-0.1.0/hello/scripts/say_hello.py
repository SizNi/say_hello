print("Hello!")
