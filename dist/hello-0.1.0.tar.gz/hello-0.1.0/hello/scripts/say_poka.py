from colorama import Fore
def main():
    print(Fore.RED + 'poka poka')
if __name__ == '__main__':
    main()
